# Engine integration status — v0.5

## Added
- AndroidX Media3 Transformer dependencies (1.6.1).
- `MediaExportManager`: actual device-codec MP4 export of one selected source clip, optionally trimmed by in/out timestamps.
- `ProjectFileStore`: save/load project JSON in app-private storage.
- Project/keyframe/timeline data model and cubic Bezier interpolation from v0.4.

## Important limitations
This is not yet a full-project renderer. Export currently handles one source clip at a time; it does not composite all timeline tracks, transitions, animated overlays, masks, chroma key, color grading or mixed audio. The UI still needs to be wired to the export manager and project store. Media3 API integration has not been compiled or tested in this environment because Android SDK and Gradle are unavailable.

## Device compatibility
minSdk 28 / compileSdk 36. Actual compatibility, codecs, permissions, output file handling and performance must be verified by Gradle build and physical-device testing on Android 9 through 16.
