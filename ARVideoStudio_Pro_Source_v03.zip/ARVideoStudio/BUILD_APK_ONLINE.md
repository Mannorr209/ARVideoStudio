# Build APK with one workflow run

This repository includes `.github/workflows/build-apk.yml`.

1. Upload this project ZIP to a new GitHub repository (extract it first; upload the files and folders, including the hidden `.github` folder).
2. Open the repository's **Actions** tab.
3. Select **Build AR Video Studio APK**.
4. Press **Run workflow**.
5. When the run completes successfully, open the run and download the artifact named **AR-Video-Studio-debug-APK**.
6. Extract the artifact ZIP on the Android phone and install `app-debug.apk`. Android may ask permission to install apps from that source.

The workflow builds a debug APK. It is suitable for testing, not a signed production release for Play Store distribution.

A successful CI build is not the same as full editor feature completion. The current app remains a prototype: it does not yet render all timeline tracks/effects/keyframes into a final video. Test the generated APK on real devices before relying on it.
