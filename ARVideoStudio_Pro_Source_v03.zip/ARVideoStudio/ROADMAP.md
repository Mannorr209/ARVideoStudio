# AR Video Studio — feature status

| Feature | Status in v0.3 |
|---|---|
| Import multiple video clips | Implemented in UI / Android document picker |
| Timeline and clip selection | Basic prototype |
| Remove selected clip | Implemented |
| Animation panel | Implemented |
| Add keyframes | Implemented as in-memory data |
| Delete nearest keyframe | Implemented as in-memory data |
| Scale and rotation controls | UI controls; not yet rendered |
| Speed and volume controls | UI controls; not yet applied to export |
| Color section | UI controls only |
| Audio section | UI placeholder/control only |
| Text section | Text input UI only |
| Masks section | UI placeholder |
| Effects section | UI placeholder |
| Real Bezier interpolation | Not implemented |
| MP4 render/export | Not implemented |
| Persistent project save/load | Not implemented |

## Next engineering work
Connect a media rendering pipeline (for example AndroidX Media3 Transformer) for trimming, speed, rotation, audio gain and export; implement a multi-track project model; add keyframe interpolation (linear/ease/cubic Bezier); then add GPU effects, masks, chroma key, transitions, text overlays, audio mixing and device-specific export profiles.

Do not ship this prototype as a finished editor. Verify builds and codec behavior on Android 9–16 devices before release.
