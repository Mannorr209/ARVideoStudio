package com.arvideostudio.core

import kotlin.math.pow

/**
 * Deterministic keyframe evaluator.
 * Cubic Bezier solves x(t) with binary search, then evaluates y(t).
 */
object KeyframeEngine {
    fun evaluate(frames: List<KeyframePoint>, timeMs: Long, fallback: Transform = Transform()): Transform {
        if (frames.isEmpty()) return fallback
        val sorted = frames.sortedBy { it.timeMs }
        if (timeMs <= sorted.first().timeMs) return sorted.first().value
        if (timeMs >= sorted.last().timeMs) return sorted.last().value
        val rightIndex = sorted.indexOfFirst { it.timeMs >= timeMs }
        val left = sorted[rightIndex - 1]
        val right = sorted[rightIndex]
        val span = (right.timeMs - left.timeMs).coerceAtLeast(1)
        val raw = ((timeMs - left.timeMs).toFloat() / span).coerceIn(0f, 1f)
        val t = when (left.interpolation) {
            Interpolation.HOLD -> 0f
            Interpolation.LINEAR -> raw
            Interpolation.EASE_IN -> raw * raw
            Interpolation.EASE_OUT -> 1f - (1f - raw) * (1f - raw)
            Interpolation.EASE_IN_OUT -> if (raw < .5f) 2f * raw * raw else 1f - (-2f * raw + 2f).pow(2) / 2f
            Interpolation.CUBIC_BEZIER -> bezierProgress(raw, left.bezierX1, left.bezierY1, left.bezierX2, left.bezierY2)
        }
        return interpolate(left.value, right.value, t)
    }

    private fun interpolate(a: Transform, b: Transform, t: Float) = Transform(
        x = mix(a.x, b.x, t), y = mix(a.y, b.y, t),
        scaleX = mix(a.scaleX, b.scaleX, t), scaleY = mix(a.scaleY, b.scaleY, t),
        rotation = mix(a.rotation, b.rotation, t), opacity = mix(a.opacity, b.opacity, t)
    )

    private fun mix(a: Float, b: Float, t: Float) = a + (b - a) * t

    private fun bezierProgress(x: Float, x1: Float, y1: Float, x2: Float, y2: Float): Float {
        fun curve(t: Float, p1: Float, p2: Float) {
            val u = 1f - t
            // Kept as a local helper below via expression-compatible calculation.
        }
        fun cubic(t: Float, p1: Float, p2: Float): Float {
            val u = 1f - t
            return 3f * u * u * t * p1 + 3f * u * t * t * p2 + t * t * t
        }
        var low = 0f
        var high = 1f
        repeat(18) {
            val mid = (low + high) / 2f
            if (cubic(mid, x1, x2) < x) low = mid else high = mid
        }
        return cubic((low + high) / 2f, y1, y2).coerceIn(0f, 1f)
    }
}
