package com.arvideostudio.core

import android.content.Context
import java.io.File

class ProjectFileStore(context: Context) {
    private val folder = File(context.filesDir, "projects").apply { mkdirs() }

    fun save(project: EditorProject): File {
        val safeName = project.name.replace(Regex("[^A-Za-z0-9А-Яа-я_-]"), "_").ifBlank { "project" }
        val file = File(folder, "${safeName}_${project.id}.arproj")
        file.writeText(project.toJson(), Charsets.UTF_8)
        return file
    }

    fun load(file: File): EditorProject = EditorProject.fromJson(file.readText(Charsets.UTF_8))

    fun list(): List<File> = folder.listFiles { f -> f.isFile && f.extension == "arproj" }
        ?.sortedByDescending { it.lastModified() } ?: emptyList()
}
