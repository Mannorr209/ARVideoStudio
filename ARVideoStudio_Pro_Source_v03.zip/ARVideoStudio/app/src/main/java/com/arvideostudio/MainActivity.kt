package com.arvideostudio

import android.net.Uri
import android.os.Bundle
import android.widget.VideoView
import android.media.MediaMetadataRetriever
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlin.math.roundToInt

private val Bg = Color(0xFF080812)
private val Panel = Color(0xFF171729)
private val Accent = Color(0xFF9A5BFF)
private val Cyan = Color(0xFF27D8F2)

data class EditClip(
    val uri: Uri,
    val name: String,
    var trimStartMs: Long = 0,
    var trimEndMs: Long = 0,
    val durationMs: Long = 0,
    var speed: Float = 1f,
    var volume: Float = 1f,
    var scale: Float = 1f,
    var rotation: Float = 0f
)

data class Keyframe(val timeMs: Long, val x: Float, val y: Float, val scale: Float, val rotation: Float)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ARStudioApp() }
    }
}

@Composable
fun ARStudioApp() {
    val context = LocalContext.current
    val clips = remember { mutableStateListOf<EditClip>() }
    val keyframes = remember { mutableStateListOf<Keyframe>() }
    var selected by remember { mutableIntStateOf(0) }
    var playhead by remember { mutableLongStateOf(0L) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var rotation by remember { mutableFloatStateOf(0f) }
    var speed by remember { mutableFloatStateOf(1f) }
    var volume by remember { mutableFloatStateOf(1f) }
    var activeTab by remember { mutableStateOf("Анимация") }
    var status by remember { mutableStateOf("Создайте проект и добавьте видео") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            try {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            val duration = runCatching {
                MediaMetadataRetriever().let { retriever ->
                    try {
                        retriever.setDataSource(context, uri)
                        retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    } finally { retriever.release() }
                }
            }.getOrDefault(0L)
            clips.add(EditClip(
                uri = uri,
                name = uri.lastPathSegment ?: "Видео ${clips.size + 1}",
                trimEndMs = duration,
                durationMs = duration
            ))
        }
        if (uris.isNotEmpty()) {
            selected = clips.lastIndex
            status = "Добавлено клипов: ${uris.size}"
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent, secondary = Cyan,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Bg) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("AR VIDEO STUDIO", fontSize = 19.sp, fontWeight = FontWeight.Black)
                        Text("PRO  •  CREATIVE VIDEO EDITOR", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = { status = "Проект пока хранится в текущем сеансе" }) {
                        Icon(Icons.Default.Save, "Сохранить проект", tint = Color.White)
                    }
                    IconButton(onClick = { status = "Экспортный модуль ещё не подключён" }) {
                        Icon(Icons.Default.FileUpload, "Экспорт", tint = Accent)
                    }
                }

                Box(
                    Modifier.fillMaxWidth().weight(0.85f).clip(RoundedCornerShape(16.dp))
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    if (clips.isNotEmpty() && selected in clips.indices) {
                        key(clips[selected].uri) {
                            AndroidView(
                                modifier = Modifier.fillMaxSize(),
                                factory = { ctx ->
                                    VideoView(ctx).apply {
                                        setVideoURI(clips[selected].uri)
                                        setOnPreparedListener { mp -> mp.isLooping = true; start() }
                                    }
                                }
                            )
                        }
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.MovieEdit, null, tint = Accent, modifier = Modifier.size(52.dp))
                            Text("Окно предпросмотра", color = Color.LightGray)
                            Text("Добавьте видео для начала монтажа", color = Color.Gray, fontSize = 11.sp)
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { picker.launch(arrayOf("video/*")) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent)
                    ) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("Импорт медиа") }
                    OutlinedButton(onClick = { status = "Экспорт MP4: движок рендеринга будет следующим этапом" }) {
                        Text("Экспорт")
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("МОНТАЖНАЯ ШКАЛА", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("${clips.size} клип(ов)", color = Cyan, fontSize = 10.sp)
                }
                LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.height(58.dp)) {
                    itemsIndexed(clips) { index, clip ->
                        Surface(
                            onClick = { selected = index },
                            color = if (selected == index) Accent.copy(alpha = .30f) else Panel,
                            shape = RoundedCornerShape(9.dp),
                            border = BorderStroke(1.dp, if (selected == index) Accent else Color.DarkGray)
                        ) {
                            Column(Modifier.width(118.dp).padding(8.dp), verticalArrangement = Arrangement.Center) {
                                Text("ВИДЕО ${index + 1}", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                Text(clip.name, maxLines = 1, fontSize = 10.sp)
                            }
                        }
                    }
                    if (clips.isEmpty()) item { Text("Клипы появятся здесь", color = Color.Gray, fontSize = 11.sp) }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("ДОРОЖКИ", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    if (clips.isNotEmpty()) {
                        TextButton(onClick = {
                            val index = selected.coerceIn(clips.indices)
                            clips.removeAt(index)
                            selected = (index - 1).coerceAtLeast(0)
                            status = "Клип удалён из проекта"
                        }) { Text("Удалить", color = Color(0xFFFF7B8B), fontSize = 10.sp) }
                        TextButton(onClick = {
                            val index = selected.coerceIn(clips.indices)
                            val clip = clips[index]
                            val splitAt = playhead.coerceIn(clip.trimStartMs + 1, (clip.trimEndMs - 1).coerceAtLeast(clip.trimStartMs + 1))
                            if (clip.durationMs > 1 && splitAt > clip.trimStartMs && splitAt < clip.trimEndMs) {
                                clips[index] = clip.copy(trimEndMs = splitAt)
                                clips.add(index + 1, clip.copy(
                                    name = clip.name + " (часть 2)",
                                    trimStartMs = splitAt
                                ))
                                selected = index + 1
                                status = "Клип разделён на две части по позиции ${splitAt / 1000} с"
                            } else {
                                status = "Переместите ползунок внутрь выбранного клипа для разделения"
                            }
                        }) { Text("Разделить", color = Cyan, fontSize = 10.sp) }
                    }
                    Text("00:${(playhead / 1000).toString().padStart(2, '0')}", color = Cyan, fontSize = 11.sp)
                }
                Slider(
                    value = playhead.toFloat().coerceIn(0f, 60000f),
                    onValueChange = { playhead = it.roundToInt().toLong() },
                    valueRange = 0f..60000f,
                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    listOf("Анимация", "Скорость", "Цвет", "Звук", "Текст", "Маски", "Эффекты").forEach { tab ->
                        FilterChip(
                            selected = activeTab == tab,
                            onClick = { activeTab = tab },
                            label = { Text(tab, fontSize = 11.sp) }
                        )
                    }
                }

                when (activeTab) {
                    "Анимация" -> {
                        Text("КЛЮЧЕВЫЕ КАДРЫ", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    keyframes.add(Keyframe(playhead, 0f, 0f, zoom, rotation))
                                    status = "Ключевой кадр добавлен: ${keyframes.size}"
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Accent),
                                modifier = Modifier.weight(1f)
                            ) { Icon(Icons.Default.Add, null); Text("Добавить кадр") }
                            OutlinedButton(
                                onClick = {
                                    val nearest = keyframes.indices.minByOrNull { kotlin.math.abs(keyframes[it].timeMs - playhead) }
                                    if (nearest != null) {
                                        keyframes.removeAt(nearest)
                                        status = "Ближайший ключевой кадр удалён"
                                    } else status = "Нет ключевых кадров"
                                }
                            ) { Text("Удалить кадр") }
                        }
                        Text("Масштаб  ${"%.2f".format(zoom)}×", fontSize = 11.sp)
                        Slider(value = zoom, onValueChange = { zoom = it }, valueRange = .25f..3f)
                        Text("Поворот  ${rotation.roundToInt()}°", fontSize = 11.sp)
                        Slider(value = rotation, onValueChange = { rotation = it }, valueRange = -180f..180f)
                        Text("Ключевых кадров: ${keyframes.size}  •  X/Y, масштаб и поворот", color = Color.Gray, fontSize = 10.sp)
                    }
                    "Скорость" -> {
                        Text("СКОРОСТЬ КЛИПА  ${"%.2f".format(speed)}×", color = Cyan, fontSize = 11.sp)
                        Slider(value = speed, onValueChange = { speed = it }, valueRange = .25f..3f)
                        Text("Звук клипа  ${"%.0f".format(volume * 100)}%", color = Cyan, fontSize = 11.sp)
                        Slider(value = volume, onValueChange = { volume = it }, valueRange = 0f..1f)
                    }
                    "Цвет" -> {
                        Text("ЦВЕТОКОРРЕКЦИЯ — интерфейс настроек", color = Cyan, fontSize = 11.sp)
                        Text("Яркость", fontSize = 11.sp); var a by remember { mutableFloatStateOf(0f) }; Slider(a, { a = it }, -1f..1f)
                        Text("Контраст", fontSize = 11.sp); var b by remember { mutableFloatStateOf(1f) }; Slider(b, { b = it }, 0f..2f)
                        Text("Насыщенность", fontSize = 11.sp); var c by remember { mutableFloatStateOf(1f) }; Slider(c, { c = it }, 0f..2f)
                    }
                    "Звук" -> {
                        Text("АУДИО И МИКШЕР", color = Cyan, fontSize = 11.sp)
                        Text("Громкость клипа", fontSize = 11.sp); Slider(volume, { volume = it }, 0f..1f)
                        Text("Импорт музыки и запись озвучки — следующий модуль", color = Color.Gray, fontSize = 10.sp)
                    }
                    "Текст" -> {
                        var title by remember { mutableStateOf("Ваш текст") }
                        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Текстовый слой") }, modifier = Modifier.fillMaxWidth())
                        Text("Анимация текста и титры будут подключены к рендереру", color = Color.Gray, fontSize = 10.sp)
                    }
                    "Маски" -> Text("Планируются: линейная, круговая, перо и маскирование по форме.", color = Color.LightGray, fontSize = 11.sp)
                    "Эффекты" -> Text("Планируются: blur, glow, glitch, chroma key, переходы и LUT.", color = Color.LightGray, fontSize = 11.sp)
                }
                Text(status, color = Color.LightGray, fontSize = 10.sp)
                Text("AR Video Studio Pro • тестовая сборка проекта • без рекламы", color = Color.Gray, fontSize = 9.sp)
            }
        }
    }
}
