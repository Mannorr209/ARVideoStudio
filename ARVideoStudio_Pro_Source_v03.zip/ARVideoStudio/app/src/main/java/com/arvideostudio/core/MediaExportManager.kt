package com.arvideostudio.core

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File

/**
 * Device-codec MP4 export for a single source clip.
 * This is deliberately explicit: a full multi-track compositor must build a Composition
 * from the project's tracks before it can be advertised as full-project export.
 */
class MediaExportManager(
    context: Context,
    private val onComplete: (File) -> Unit,
    private val onFailure: (Throwable) -> Unit
) {
    private val appContext = context.applicationContext
    private var transformer: Transformer? = null

    fun exportSingleClip(
        source: Uri,
        output: File,
        startMs: Long = 0L,
        endMs: Long? = null
    ) {
        try {
            output.parentFile?.mkdirs()
            if (output.exists()) output.delete()

            val mediaItemBuilder = MediaItem.Builder().setUri(source)
            if (endMs != null && endMs > startMs) {
                mediaItemBuilder.setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(startMs)
                        .setEndPositionMs(endMs)
                        .build()
                )
            }

            val edited = EditedMediaItem.Builder(mediaItemBuilder.build()).build()
            transformer = Transformer.Builder(appContext)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                        onComplete(output)
                    }

                    override fun onError(
                        composition: androidx.media3.transformer.Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        onFailure(exportException)
                    }
                })
                .build()
            transformer?.start(edited, output.absolutePath)
        } catch (t: Throwable) {
            onFailure(t)
        }
    }

    fun cancel() {
        transformer?.cancel()
        transformer = null
    }
}
