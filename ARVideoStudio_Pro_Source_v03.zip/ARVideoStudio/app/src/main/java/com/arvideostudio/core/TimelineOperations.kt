package com.arvideostudio.core

/**
 * Pure timeline operations. UI and renderer can share the same project model.
 */
object TimelineOperations {
    fun addClip(track: TimelineTrack, clip: TimelineClip): TimelineTrack {
        require(!track.locked) { "Track is locked" }
        return track.copy(clips = (track.clips + clip).sortedBy { it.timelineStartMs })
    }

    fun removeClip(track: TimelineTrack, clipId: String): TimelineTrack {
        require(!track.locked) { "Track is locked" }
        return track.copy(clips = track.clips.filterNot { it.id == clipId })
    }

    fun moveClip(track: TimelineTrack, clipId: String, newStartMs: Long): TimelineTrack {
        require(!track.locked) { "Track is locked" }
        return track.copy(clips = track.clips.map {
            if (it.id == clipId) it.copy(timelineStartMs = newStartMs.coerceAtLeast(0)) else it
        }.sortedBy { it.timelineStartMs })
    }

    fun trimClip(clip: TimelineClip, newInMs: Long, newOutMs: Long): TimelineClip {
        require(newInMs >= 0 && newOutMs > newInMs) { "Invalid trim range" }
        return clip.copy(sourceInMs = newInMs, sourceOutMs = newOutMs)
    }

    fun addKeyframe(clip: TimelineClip, frame: KeyframePoint): TimelineClip =
        clip.copy(keyframes = (clip.keyframes.filterNot { it.timeMs == frame.timeMs } + frame).sortedBy { it.timeMs })

    fun removeKeyframe(clip: TimelineClip, keyframeId: String): TimelineClip =
        clip.copy(keyframes = clip.keyframes.filterNot { it.id == keyframeId })
}
