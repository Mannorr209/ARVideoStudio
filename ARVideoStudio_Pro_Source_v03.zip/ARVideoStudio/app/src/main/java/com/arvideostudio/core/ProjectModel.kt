package com.arvideostudio.core

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class TrackType { VIDEO, AUDIO, TEXT, IMAGE, OVERLAY }
enum class Interpolation { HOLD, LINEAR, EASE_IN, EASE_OUT, EASE_IN_OUT, CUBIC_BEZIER }

data class Transform(
    val x: Float = 0f,
    val y: Float = 0f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val rotation: Float = 0f,
    val opacity: Float = 1f
)

data class KeyframePoint(
    val id: String = UUID.randomUUID().toString(),
    val timeMs: Long,
    val value: Transform,
    val interpolation: Interpolation = Interpolation.EASE_IN_OUT,
    val bezierX1: Float = 0.25f,
    val bezierY1: Float = 0.1f,
    val bezierX2: Float = 0.25f,
    val bezierY2: Float = 1f
)

data class TimelineClip(
    val id: String = UUID.randomUUID().toString(),
    val sourceUri: String,
    val title: String,
    val timelineStartMs: Long = 0,
    val sourceInMs: Long = 0,
    val sourceOutMs: Long = 0,
    val speed: Float = 1f,
    val volume: Float = 1f,
    val transform: Transform = Transform(),
    val keyframes: List<KeyframePoint> = emptyList()
) {
    val durationMs: Long get() = ((sourceOutMs - sourceInMs).coerceAtLeast(0) / speed.coerceAtLeast(0.01f)).toLong()
    val timelineEndMs: Long get() = timelineStartMs + durationMs
}

data class TimelineTrack(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: TrackType,
    val muted: Boolean = false,
    val locked: Boolean = false,
    val clips: List<TimelineClip> = emptyList()
)

data class EditorProject(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Новый проект",
    val width: Int = 1920,
    val height: Int = 1080,
    val frameRate: Int = 30,
    val tracks: List<TimelineTrack> = listOf(
        TimelineTrack(name = "Видео 1", type = TrackType.VIDEO),
        TimelineTrack(name = "Аудио 1", type = TrackType.AUDIO),
        TimelineTrack(name = "Текст", type = TrackType.TEXT)
    )
) {
    fun toJson(): String {
        val root = JSONObject()
        root.put("id", id); root.put("name", name)
        root.put("width", width); root.put("height", height); root.put("frameRate", frameRate)
        val trackArray = JSONArray()
        tracks.forEach { track ->
            val t = JSONObject()
            t.put("id", track.id); t.put("name", track.name); t.put("type", track.type.name)
            t.put("muted", track.muted); t.put("locked", track.locked)
            val clipArray = JSONArray()
            track.clips.forEach { clip ->
                val c = JSONObject()
                c.put("id", clip.id); c.put("sourceUri", clip.sourceUri); c.put("title", clip.title)
                c.put("timelineStartMs", clip.timelineStartMs); c.put("sourceInMs", clip.sourceInMs)
                c.put("sourceOutMs", clip.sourceOutMs); c.put("speed", clip.speed); c.put("volume", clip.volume)
                c.put("transform", JSONObject().apply {
                    put("x", clip.transform.x); put("y", clip.transform.y)
                    put("scaleX", clip.transform.scaleX); put("scaleY", clip.transform.scaleY)
                    put("rotation", clip.transform.rotation); put("opacity", clip.transform.opacity)
                })
                val frames = JSONArray()
                clip.keyframes.forEach { k ->
                    frames.put(JSONObject().apply {
                        put("id", k.id); put("timeMs", k.timeMs); put("interpolation", k.interpolation.name)
                        put("x", k.value.x); put("y", k.value.y); put("scaleX", k.value.scaleX)
                        put("scaleY", k.value.scaleY); put("rotation", k.value.rotation); put("opacity", k.value.opacity)
                        put("x1", k.bezierX1); put("y1", k.bezierY1); put("x2", k.bezierX2); put("y2", k.bezierY2)
                    })
                }
                c.put("keyframes", frames); clipArray.put(c)
            }
            t.put("clips", clipArray); trackArray.put(t)
        }
        root.put("tracks", trackArray)
        return root.toString(2)
    }

    companion object {
        fun fromJson(json: String): EditorProject {
            val root = JSONObject(json)
            val tracks = mutableListOf<TimelineTrack>()
            val ta = root.optJSONArray("tracks") ?: JSONArray()
            for (i in 0 until ta.length()) {
                val t = ta.getJSONObject(i)
                val clips = mutableListOf<TimelineClip>()
                val ca = t.optJSONArray("clips") ?: JSONArray()
                for (j in 0 until ca.length()) {
                    val c = ca.getJSONObject(j)
                    val tr = c.optJSONObject("transform") ?: JSONObject()
                    val frames = mutableListOf<KeyframePoint>()
                    val fa = c.optJSONArray("keyframes") ?: JSONArray()
                    for (k in 0 until fa.length()) {
                        val f = fa.getJSONObject(k)
                        frames += KeyframePoint(
                            id = f.optString("id", UUID.randomUUID().toString()),
                            timeMs = f.optLong("timeMs"),
                            value = Transform(
                                f.optDouble("x").toFloat(), f.optDouble("y").toFloat(),
                                f.optDouble("scaleX", 1.0).toFloat(), f.optDouble("scaleY", 1.0).toFloat(),
                                f.optDouble("rotation").toFloat(), f.optDouble("opacity", 1.0).toFloat()
                            ),
                            interpolation = runCatching { Interpolation.valueOf(f.optString("interpolation")) }.getOrDefault(Interpolation.EASE_IN_OUT),
                            bezierX1 = f.optDouble("x1", .25).toFloat(),
                            bezierY1 = f.optDouble("y1", .1).toFloat(),
                            bezierX2 = f.optDouble("x2", .25).toFloat(),
                            bezierY2 = f.optDouble("y2", 1.0).toFloat()
                        )
                    }
                    clips += TimelineClip(
                        id = c.optString("id", UUID.randomUUID().toString()),
                        sourceUri = c.optString("sourceUri"), title = c.optString("title"),
                        timelineStartMs = c.optLong("timelineStartMs"),
                        sourceInMs = c.optLong("sourceInMs"), sourceOutMs = c.optLong("sourceOutMs"),
                        speed = c.optDouble("speed", 1.0).toFloat(), volume = c.optDouble("volume", 1.0).toFloat(),
                        transform = Transform(
                            tr.optDouble("x").toFloat(), tr.optDouble("y").toFloat(),
                            tr.optDouble("scaleX", 1.0).toFloat(), tr.optDouble("scaleY", 1.0).toFloat(),
                            tr.optDouble("rotation").toFloat(), tr.optDouble("opacity", 1.0).toFloat()
                        ),
                        keyframes = frames
                    )
                }
                tracks += TimelineTrack(
                    id = t.optString("id", UUID.randomUUID().toString()),
                    name = t.optString("name"),
                    type = runCatching { TrackType.valueOf(t.optString("type")) }.getOrDefault(TrackType.VIDEO),
                    muted = t.optBoolean("muted"), locked = t.optBoolean("locked"), clips = clips
                )
            }
            return EditorProject(
                id = root.optString("id", UUID.randomUUID().toString()),
                name = root.optString("name", "Новый проект"),
                width = root.optInt("width", 1920), height = root.optInt("height", 1080),
                frameRate = root.optInt("frameRate", 30), tracks = tracks
            )
        }
    }
}
