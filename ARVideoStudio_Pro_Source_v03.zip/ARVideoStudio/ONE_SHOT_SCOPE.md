# AR Video Studio — consolidated delivery scope

This archive combines the Android UI prototype and reusable editor core foundations.

## Present in source
- Multi-file video import UI and clip selection/removal.
- Basic preview via Android VideoView.
- Timeline playhead and track/clip project data structures.
- Keyframe model for position, scale, rotation and opacity.
- Keyframe interpolation: hold, linear, easing and cubic Bezier.
- Pure timeline operations: add/remove/move/trim clips.
- JSON serialization/deserialization for project model.
- UI sections for animation, speed, color, audio, text, masks and effects.
- No ad SDK, analytics SDK, account system or network permission.

## Not yet a finished production editor
The code does not yet provide the full rendering/compositing engine, multi-track synchronized preview, waveform/audio mixing, GPU effects, mask/green-screen rendering, speech recognition, or final MP4 export. The screen's placeholder controls do not imply those render functions are complete. A real release requires integrating a maintained Android media pipeline and GPU renderer, then testing output on physical devices.

## Compatibility target
minSdk 28 (Android 9); compileSdk 36. Android 9–16 is a target range, not a verified guarantee. Test API levels, OEM codecs, memory pressure, permissions, and thermal behavior.

## Size
The ZIP size is not the APK size. Final APK/AAB size depends on bundled native libraries, ABI splits, codecs, fonts, and effects. Build release artifacts in Android Studio and measure the generated APK/AAB before making size claims.
